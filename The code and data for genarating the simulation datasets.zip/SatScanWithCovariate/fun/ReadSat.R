ReadSat <- function(filegis.txt,alpha){
  gis <- read.table(filegis.txt,colClasses = c("character","numeric","numeric"))[,c(2,1,3)]
  names(gis) <- c("cluster","code","p")
  gis <- subset(gis,p <= alpha)
}