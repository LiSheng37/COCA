minaxe <- function(coordinate,centre,shape,theta){
  # 已知离心率、中心、椭圆与x轴的角度及椭圆上一点计算椭圆的半短轴
  # coordinate：vector，椭圆上某点坐标，centre：vector，椭圆中心，shape：离心率，theta:角度，0-2pi
  sqrt((((coordinate[1]-centre[1])*cos(theta)+(coordinate[2]-centre[2])*sin(theta))/shape)^2 + 
         ((coordinate[2]-centre[2])*cos(theta)-(coordinate[1]-centre[1])*sin(theta))^2)
}