GenerateSimData_x2 <- function(basedat,totalcases,cluster,beta,RR,theta,nsim){
  n_county <- dim(basedat)[1]
  cluster_code <- basedat$code %in% cluster
  basedat$p <- exp(basedat$x * beta)
  beta1 <- beta*theta
  basedat$p[cluster_code] <- exp(basedat$x[cluster_code] * beta1)
  basedat$p[cluster_code] <- basedat$p[cluster_code] * RR
  basedat$expect_loc <- basedat$pop * basedat$p
  case_sim <- matrix(,ncol = nsim,nrow = n_county)
  row.names(case_sim) <- basedat$code
  for (i in 1:nsim) {
    casei <- mcmc_fun(code = basedat$code,size = totalcases,prob = basedat$expect_loc)
    case_sim[,i] <- casei 
  }
  return(case_sim)
}
