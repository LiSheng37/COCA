ReadClusterToCatvariable <- function(file,code,alpha = 0.05){
  # file 文件必须为gis.txt文件from result of SatScan
  # code 为数据集中的location编码，顺序必须与分析中所用数据集一致
  gis <- read.table(file,colClasses = c("character","numeric","numeric"))
  gis <- subset(gis,V3 <= alpha, select = c(V1,V2))
  code <- as.data.frame(code)
  catvar <- merge(code,gis,by.x = "code",by.y = "V1",all.x = T)
  catvar$V2[is.na(catvar$V2)] <- 0
  catvar <- catvar[match(code$code,catvar$code),]
  as.factor(catvar[,2])
}