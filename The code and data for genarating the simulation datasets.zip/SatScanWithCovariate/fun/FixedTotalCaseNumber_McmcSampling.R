mcmc_fun <- function(code,size,prob){
  # 该函数为蒙特卡洛抽样 for poisson distribution，condition on the fixed total case number
  # code:vecttor为各区域编码，size:numeric为抽样大小，即总发病数，prob:vector,各地区的期望发病数
  case_mcmc <- sample(code,size = size,replace = T, prob = prob)
  case_mcmc <- as.vector(table(case_mcmc)[code])
  names(case_mcmc) <- code
  case_mcmc[is.na(case_mcmc)] <- 0
  case_mcmc
}