sim2cas <- function(scenario,readn = NULL){
  # 将某一个模拟策略中的数据，依次读入为flexscan支持的cas文件
  # readn 为需要读入的数据个数
  pop <- read.table(paste(path,"neast.pop",sep = ""),header = T,colClasses = c("character","character","integer","integer"))
  dir.create(paste(path,scenario,sep = ""),showWarnings = F)
  cas <- pop[,c(2,3,4)]
  xx <- read.table(file = paste(path,scenario,".sim",sep = ""))
  cas$pop <- sum(xx[,2])/sum(cas$pop) * cas$pop
  names(cas) <- c("code","observe","expect0")
  if(is.null(readn)) readn <- dim(xx)[2]-1
  for (i in 1:readn) {
    cas$observe <- xx[,i+1]
    write.table(cas,file = paste(path,scenario,"/sim",i,".cas",sep = ""),quote = F,col.names = F,row.names = F)
	}
  cat(i,"cas files have been generated from",scenario,"\n")
}
# scenario <- "6000urban2county1.5shape"
# sim2cas(scenario = scenario)
