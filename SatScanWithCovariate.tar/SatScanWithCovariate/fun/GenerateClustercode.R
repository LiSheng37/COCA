# 给定cluster的中心，包含的county个数，窗口形状，angle
# 输出组成cluster的county code
# 20180922


#' @param centre A vector of character indicating the centres of clusters
#' @param shape numeric. The shape of cluster. 椭圆的长短轴之比。表示圆形
#' @param num_county An integer indicating the number of counties included in clusters
#' @param geodat Satscan里的geofile. 必须按照目前指定的名字命名变量
#' @param theta cluster 性状的方向
GenerateClustercode <- function(centre,shape,num_county,geodat,theta = 1/6){
  theta <- theta * pi
  geo <- geodat
  n_county <- dim(geo)[1]
  cluster <- NULL
  for (i in 1:length(centre)) {
  centrei <- c(geo[geo$code==centre[i],"x"],geo[geo$code==centre[i],"y"])
  # cluster 选择
  minaxes <- apply(geo[,c("x","y")], 1, minaxe,shape=shape,centre=centrei,theta=theta)
  names(minaxes) <- geo$code
  minaxes <- sort(minaxes)
  cluster <- c(cluster,names(minaxes)[1:num_county])
  }
  return(cluster)
}