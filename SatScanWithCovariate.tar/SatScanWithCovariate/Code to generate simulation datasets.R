########## load function and data, set path====================================
`%+%` <- function(x,y) paste0(x,y)
`%>%` <- magrittr::`%>%` # pipe operator
path <-  "E:/SatScanWithCovariate/"
pathdat <- path%+%"SimulateData/"
pathfun <- path%+%"fun/"
Rfun <- dir(pathfun) %>% .[grepl(pattern = ".R",x = .)]
invisible(lapply(pathfun%+%Rfun,source))  # loading function
library(rsatscan)
library(dplyr)
library(ggplot2)
library(cowplot)
library(sp)
####### 1、模拟生成x变量=======================================================
pop <- read.table(pathdat%+%"neast.pop",stringsAsFactors = F,header = T,
                  colClasses = c("character","character","integer","integer"))
geo <- read.table(pathdat%+%"neast.geo",stringsAsFactors = F,header = T,
                  colClasses = c("character","character","integer","integer"))
pop <- pop[,c(1:4)]
#可视化###
#library(sp)
geodata = data.frame(lon = geo$x,
                     lat = geo$y,
                     city = geo$code)
coordinates(geodata) <- ~ lon + lat
plot(geodata)
map <- rgdal::readOGR(pathdat%+%"COUNTIES.SHP")
plot(map)
#生成IDW矩阵
distmat <- dist(geo[,c(3,4)]) %>% as.matrix() 
dismat <- as.matrix(distmat)
fn = function(x)
{
  return(1/(x^2))
}
w <- apply(distmat, 1:2, fn)
for(i in 1:245){
  w[i,i]=0
}
w <- sweep(w, 1, rowSums(w), FUN = "/") #进行行的归一化，对称的行合计和列合计的和是相同的
size <- 8
####1.1 无X聚集区，一个Y聚集区的情况#######
#确定Y的聚集区（一直都是这个）
set.seed(555)
sample(geo$code,1) #"50005" 人数七万人）
Rcluster2 <- GenerateClustercode(centre = c("36047"),shape = 1,num_county = 8,geodat = geo)
Rcluster2
#模拟
{
  simutime = 2000
  xsim <- matrix(ncol = simutime,nrow = 245)
  row.names(xsim) <- pop$code
  simcase1 <- matrix(ncol = simutime,nrow = 245)
  row.names(simcase1) <- pop$code
}
for(q in 1:simutime){
  s <- nrow(geo)
  resx <- rnorm(s,0,1) #生成随机误差，一个随机
  I <- diag(rep(1,s)) #生成单位矩阵
  xro <- 0.7 #空间自相关系数
  x <- solve(I-xro*w) %*% resx #生成X
  x <- as.data.frame(x)
  x$code <- geo$code
  x$adjclu <- x$V1
  x$var <- x$adjclu-x$V1
  sim <- merge(x,pop)
  colnames(sim) <- c("code","x1","x","var","name","year","pop")
  xsim[,q] <- x$adjclu
  ncases <- 3000;RR <- 3;nsim <- 1;beta <- 1.5;theta <- 1.1 
  simcase <- GenerateSimData(basedat = sim,totalcases = ncases,cluster = Rcluster2,
                               beta = beta,RR = RR,theta=theta, nsim=nsim) #每一列的总例数是3000[病例]，一个随机
  simcase1[,q] <- simcase
}
setwd("D:/covariance/simuldata/0706")
write.csv(simcase1,"sim.csv") #实际发病数
write.csv(xsim,"xsim.csv") #存储配套的X文件

 
####1.2 一个X聚集区，一个Y聚集区的情况#######
#确定Y的聚集区（一直都是这个）
set.seed(555)
set.seed(888)
sample(geo$code,1) #"50005" 人数七万人）
Rcluster2 <- GenerateClustercode(centre = c("36047"),shape = 1,num_county = 8,geodat = geo)
Rcluster2
#模拟
#随机挑选一个x聚集区
xcenter1 <- read.table(pathdat%+%"xcenter.csv",
                       stringsAsFactors = F,header = F,colClasses = c("character"))
xcenter <- as.character(xcenter1$V2)
size=8
Rclusterx=c()
for (i in 1:16){
  xcenter1 <- xcenter[i]
  Rcluster1 <- GenerateClustercode(centre = xcenter1 ,shape = 1,num_county = size,geodat = geo)
  Rclusterx <- rbind(Rclusterx,Rcluster1)
}
Rclusterx <- data.frame(Rclusterx)
#小试牛刀聚集区的X加Cx
for(i in 1:245){
  for(j in 1:8){
    if(x$code[i] == Rclusterx3[j]){
      x$adjclu[i] <-  x$V1[i]+1
    }
  }
}
{
  simutime = 2000
  xsim <- matrix(ncol = simutime,nrow = 245)
  row.names(xsim) <- pop$code
  simcase1 <- matrix(ncol = simutime,nrow = 245)
  row.names(simcase1) <- pop$code
}
for(q in 1:simutime){
  s <- nrow(geo)
  resx <- rnorm(s,0,1) #生成随机误差，一个随机
  I <- diag(rep(1,s)) #生成单位矩阵
  xro <- 0.7 #空间自相关系数
  x <- solve(I-xro*w) %*% resx #生成X
  x <- as.data.frame(x)
  x$code <- geo$code
  x$adjclu <- x$V1
  #x的聚集区与Y重合，即为Rcluster2
  xrow <- sample(1:16,1) #随机挑选出一个
  Rclusterx2 <- as.character(Rclusterx[xrow,])
  for(i in 1:245){
    for(j in 1:8){
      if(x$code[i] == Rclusterx2[j]){
        x$adjclu[i] <-  x$V1[i]+1
      }
    }
  }
  x$var <- x$adjclu-x$V1
  sim <- merge(x,pop)
  colnames(sim) <- c("code","x1","x","var","name","year","pop")
  xsim[,q] <- x$adjclu
  ncases <- 3000;RR <- 3;nsim <- 1;beta <- 1.5;theta <- 1.1  
  simcase <- GenerateSimData(basedat = sim,totalcases = ncases,cluster = Rcluster2,
                               beta = beta,RR = RR,theta=theta, nsim=nsim) #每一列的总例数是3000[病例]，一个随机
  simcase1[,q] <- simcase
}
setwd("D:/covariance/simuldata/0706")
write.csv(simcase1,"sim.csv") #实际发病数
write.csv(xsim,"xsim.csv") #存储配套的X文件


###1.3 两个X聚集区（一个高一个低），一个Y聚集区的情况#######
#确定Y的聚集区（一直都是这个）
xcenter1 <- read.table(pathdat%+%"xcenter.csv",
                       stringsAsFactors = F,header = F,colClasses = c("character"))
xcenter <- as.character(xcenter1$V2)
size=8
Rclusterx=c()
for (i in 1:16){
  xcenter1 <- xcenter[i]
  Rcluster1 <- GenerateClustercode(centre = xcenter1 ,shape = 1,num_county = size,geodat = geo)
  Rclusterx <- rbind(Rclusterx,Rcluster1)
}
Rclusterx <- data.frame(Rclusterx)
#Y聚集区
Rcluster2 <- GenerateClustercode(centre = c("36047"),shape = 1,num_county = 8,geodat = geo)
Rcluster2
#模拟
{
  simutime = 2000
  xsim <- matrix(ncol = simutime,nrow = 245)
  row.names(xsim) <- pop$code
  simcase1 <- matrix(ncol = simutime,nrow = 245)
  row.names(simcase1) <- pop$code
}
for(q in 1:simutime){
  s <- nrow(geo)
  resx <- rnorm(s,0,1) #生成随机误差，一个随机
  I <- diag(rep(1,s)) #生成单位矩阵
  xro <- 0.7 #空间自相关系数
  x <- solve(I-xro*w) %*% resx #生成X
  x <- as.data.frame(x)
  x$code <- geo$code
  x$adjclu <- x$V1
  #两个高聚集区
  xrow <- sample(1:16,1) #随机挑选出一个
  Rclusterx2.1 <- as.character(Rclusterx[xrow,])
  for(i in 1:245){
    for(j in 1:8){
      if(x$code[i] == Rclusterx2.1[j]){
        x$adjclu[i] <-  x$V1[i]+1
      }
    }
  }
  x$var <- x$adjclu-x$V1
  Rclusterx.1 <- Rclusterx[-xrow,]
  xrow2 <- sample(1:15,1)
  Rclusterx2.2 <- as.character(Rclusterx.1[xrow2,])
  #聚集区的X加Cx
  for(i in 1:245){
    for(j in 1:8){
      if(x$code[i] == Rclusterx2.2[j]){
        x$adjclu[i] <-  x$V1[i]-1
      }
    }
  }
  x$var <- x$adjclu-x$V1
  sim <- merge(x,pop)
  colnames(sim) <- c("code","x1","x","var","name","year","pop")
  xsim[,q] <- x$adjclu
  ncases <- 3000;RR <- 3;nsim <- 1;beta <- 1.5;theta <- 1.1 
  simcase <- GenerateSimData(basedat = sim,totalcases = ncases,cluster = Rcluster2,
                               beta = beta,RR = RR,theta=theta, nsim=nsim) #每一列的总例数是3000[病例]，一个随机
  simcase1[,q] <- simcase
}
setwd("D:/covariance/simuldata/0706")
write.csv(simcase1,"sim.csv") #实际发病数
write.csv(xsim,"xsim.csv") #存储配套的X文件


####1.4 无X聚集区，两个Y聚集区的情况#######
#确定Y的聚集区（一直都是这个）
Rcluster2.1 <- GenerateClustercode(centre = c("25025"),shape = 1,num_county = 8,geodat = geo)
Rcluster2.1
Rcluster2.2 <- GenerateClustercode(centre = c("36047"),shape = 1,num_county = 8,geodat = geo)
Rcluster2.2
Rcluster2 <- union(Rcluster2.1,Rcluster2.2)
#模拟
{
  simutime = 2000
  xsim <- matrix(ncol = simutime,nrow = 245)
  row.names(xsim) <- pop$code
  simcase1 <- matrix(ncol = simutime,nrow = 245)
  row.names(simcase1) <- pop$code
}
for(q in 1:simutime){
  s <- nrow(geo)
  resx <- rnorm(s,0,1) #生成随机误差，一个随机
  I <- diag(rep(1,s)) #生成单位矩阵
  xro <- 0.7 #空间自相关系数
  x <- solve(I-xro*w) %*% resx #生成X
  x <- as.data.frame(x)
  x$code <- geo$code
  x$adjclu <- x$V1
  x$var <- x$adjclu-x$V1
  sim <- merge(x,pop)
  colnames(sim) <- c("code","x1","x","var","name","year","pop")
  xsim[,q] <- x$adjclu
  ncases <- 3000;RR <- 3;nsim <- 1;beta <- 1.5;theta <- 1.1  
  simcase <- GenerateSimData(basedat = sim,totalcases = ncases,cluster = Rcluster2,
                               beta = beta,RR = RR,theta=theta, nsim=nsim) #每一列的总例数是3000[病例]，一个随机
  simcase1[,q] <- simcase
}
setwd("D:/covariance/simuldata/0706")
write.csv(simcase1,"sim.csv") #实际发病数
write.csv(xsim,"xsim.csv") #存储配套的X文件

 
####1.5 一个X聚集区，两个Y聚集区的情况#######
#确定Y的聚集区（一直都是这个）
set.seed(555)
sample(geo$code,1) #"50005" 人数七万人）
Rcluster2.1 <- GenerateClustercode(centre = c("25025"),shape = 1,num_county = 8,geodat = geo)
Rcluster2.1
Rcluster2.2 <- GenerateClustercode(centre = c("36047"),shape = 1,num_county = 8,geodat = geo)
Rcluster2.2
Rcluster2 <- union(Rcluster2.1,Rcluster2.2)
xcenter1 <- read.table(pathdat%+%"xcenter.csv",
                       stringsAsFactors = F,header = F,colClasses = c("character"))
xcenter <- as.character(xcenter1$V2)
size=8
Rclusterx=c()
for (i in 1:16){
  xcenter1 <- xcenter[i]
  Rcluster1 <- GenerateClustercode(centre = xcenter1 ,shape = 1,num_county = size,geodat = geo)
  Rclusterx <- rbind(Rclusterx,Rcluster1)
}
Rclusterx <- data.frame(Rclusterx)
#模拟
{
  simutime = 2000
  xsim <- matrix(ncol = simutime,nrow = 245)
  row.names(xsim) <- pop$code
  simcase1 <- matrix(ncol = simutime,nrow = 245)
  row.names(simcase1) <- pop$code
}
for(q in 1:simutime){
  s <- nrow(geo)
  resx <- rnorm(s,0,1) #生成随机误差，一个随机
  I <- diag(rep(1,s)) #生成单位矩阵
  xro <- 0.7 #空间自相关系数
  x <- solve(I-xro*w) %*% resx #生成X
  x <- as.data.frame(x)
  x$code <- geo$code
  x$adjclu <- x$V1
  #一个高聚集区
  xrow <- sample(1:16,1) #随机挑选出一个
  Rclusterx2 <- as.character(Rclusterx[xrow,])
  for(i in 1:245){
    for(j in 1:8){
      if(x$code[i] == Rclusterx2[j]){
        x$adjclu[i] <-  x$V1[i]+1
      }
    }
  }
  x$var <- x$adjclu-x$V1
  sim <- merge(x,pop)
  colnames(sim) <- c("code","x1","x","var","name","year","pop")
  xsim[,q] <- x$adjclu
  ncases <- 3000;RR <- 3;nsim <- 1;beta <- 1.5;theta <- 1.1  
  simcase <- GenerateSimData(basedat = sim,totalcases = ncases,cluster = Rcluster2,
                               beta = beta,RR = RR,theta=theta, nsim=nsim) #每一列的总例数是3000[病例]，一个随机
  simcase1[,q] <- simcase
}
setwd("D:/covariance/simuldata/0706")
write.csv(simcase1,"sim.csv") #实际发病数
write.csv(xsim,"xsim.csv") #存储配套的X文件


####1.6 两个X聚集区（一高一低），两个Y聚集区的情况#######
#确定Y的聚集区（一直都是这个）
set.seed(555)
sample(geo$code,1) #"50005" 人数七万人）
Rcluster2.1 <- GenerateClustercode(centre = c("25025"),shape = 1,num_county = 8,geodat = geo)
Rcluster2.1
Rcluster2.2 <- GenerateClustercode(centre = c("36047"),shape = 1,num_county = 8,geodat = geo)
Rcluster2.2
Rcluster2 <- union(Rcluster2.1,Rcluster2.2)
xcenter1 <- read.table(pathdat%+%"xcenter.csv",
                       stringsAsFactors = F,header = F,colClasses = c("character"))
xcenter <- as.character(xcenter1$V2)
size=8
Rclusterx=c()
for (i in 1:16){
  xcenter1 <- xcenter[i]
  Rcluster1 <- GenerateClustercode(centre = xcenter1 ,shape = 1,num_county = size,geodat = geo)
  Rclusterx <- rbind(Rclusterx,Rcluster1)
}
Rclusterx <- data.frame(Rclusterx)
#模拟
{
  simutime = 2000
  xsim <- matrix(ncol = simutime,nrow = 245)
  row.names(xsim) <- pop$code
  simcase1 <- matrix(ncol = simutime,nrow = 245)
  row.names(simcase1) <- pop$code
}
for(q in 1:simutime){
  s <- nrow(geo)
  resx <- rnorm(s,0,1) #生成随机误差，一个随机
  I <- diag(rep(1,s)) #生成单位矩阵
  xro <- 0.7 #空间自相关系数
  x <- solve(I-xro*w) %*% resx #生成X
  x <- as.data.frame(x)
  x$code <- geo$code
  x$adjclu <- x$V1
  #两个高聚集区
  xrow <- sample(1:16,1) #随机挑选出一个
  Rclusterx2.1 <- as.character(Rclusterx[xrow,])
  for(i in 1:245){
    for(j in 1:8){
      if(x$code[i] == Rclusterx2.1[j]){
        x$adjclu[i] <-  x$V1[i]+1
      }
    }
  }
  x$var <- x$adjclu-x$V1
  Rclusterx.1 <- Rclusterx[-xrow,]
  xrow2 <- sample(1:15,1)
  Rclusterx2.2 <- as.character(Rclusterx.1[xrow2,])
  #聚集区的X加Cx
  for(i in 1:245){
    for(j in 1:8){
      if(x$code[i] == Rclusterx2.2[j]){
        x$adjclu[i] <-  x$V1[i]-1
      }
    }
  }
  x$var <- x$adjclu-x$V1
  sim <- merge(x,pop)
  colnames(sim) <- c("code","x1","x","var","name","year","pop")
  xsim[,q] <- x$adjclu
  ncases <- 3000;RR <- 3;nsim <- 1;beta <- 1.5;theta <- 1.1 
  simcase <- GenerateSimData(basedat = sim,totalcases = ncases,cluster = Rcluster2,
                               beta = beta,RR = RR,theta=theta, nsim=nsim) #每一列的总例数是3000[病例]，一个随机
  simcase1[,q] <- simcase
}
setwd("D:/covariance/simuldata/0706")
write.csv(simcase1,"sim.csv") #实际发病数
write.csv(xsim,"xsim.csv") #存储配套的X文件


#######1.7补充第3个聚集区#######
set.seed(123)
#确定Y的聚集区（一直都是这个）
Rcluster2.1 <- GenerateClustercode(centre = c("25025"),shape = 1,num_county = 8,geodat = geo)
Rcluster2.1
Rcluster2.2 <- GenerateClustercode(centre = c("36047"),shape = 1,num_county = 8,geodat = geo)
Rcluster2.2
Rcluster2.3 <- GenerateClustercode(centre = c("36065"),shape = 1,num_county = 8,geodat = geo)##之前是42129
Rcluster2.3
Rcluster2 <- union(Rcluster2.1,Rcluster2.2)
Rcluster2 <- union(Rcluster2,Rcluster2.3)
#模拟
####(1)0x3y#########
{
  simutime = 2000
  xsim <- matrix(ncol = simutime,nrow = 245)
  row.names(xsim) <- pop$code
  simcase1 <- matrix(ncol = simutime,nrow = 245)
  row.names(simcase1) <- pop$code
}
for(q in 1:simutime){
  s <- nrow(geo)
  resx <- rnorm(s,0,1) #生成随机误差，一个随机
  I <- diag(rep(1,s)) #生成单位矩阵
  xro <- 0.7 #空间自相关系数
  x <- solve(I-xro*w) %*% resx #生成X
  x <- as.data.frame(x)
  x$code <- geo$code
  x$adjclu <- x$V1
  x$var <- x$adjclu-x$V1
  sim <- merge(x,pop)
  colnames(sim) <- c("code","x1","x","var","name","year","pop")
  xsim[,q] <- x$adjclu
  ncases <- 3000;RR <- 3;nsim <- 1;beta <- 1.5;theta <- 1.1 
  simcase <- GenerateSimData(basedat = sim,totalcases = ncases,cluster = Rcluster2,
                               beta = beta,RR = RR,theta=theta, nsim=nsim) #每一列的总例数是3000[病例]，一个随机
  simcase1[,q] <- simcase
}
setwd("D:/covariance/simuldata/0706")
write.csv(simcase1,"sim.csv") #实际发病数
write.csv(xsim,"xsim.csv") #存储配套的X文件


####(1)1x3y#########
xcenter1 <- read.table(pathdat%+%"xcenter.csv",
                       stringsAsFactors = F,header = F,colClasses = c("character"))
xcenter <- as.character(xcenter1$V2)
size=8
Rclusterx=c()
for (i in 1:16){
  xcenter1 <- xcenter[i]
  Rcluster1 <- GenerateClustercode(centre = xcenter1 ,shape = 1,num_county = size,geodat = geo)
  Rclusterx <- rbind(Rclusterx,Rcluster1)
}
Rclusterx <- data.frame(Rclusterx)
{
  simutime = 2000
  xsim <- matrix(ncol = simutime,nrow = 245)
  row.names(xsim) <- pop$code
  simcase1 <- matrix(ncol = simutime,nrow = 245)
  row.names(simcase1) <- pop$code
}
for(q in 1:simutime){
  s <- nrow(geo)
  resx <- rnorm(s,0,1) #生成随机误差，一个随机
  I <- diag(rep(1,s)) #生成单位矩阵
  xro <- 0.7 #空间自相关系数
  x <- solve(I-xro*w) %*% resx #生成X
  x <- as.data.frame(x)
  x$code <- geo$code
  x$adjclu <- x$V1
  #x的聚集区与Y重合，即为Rcluster2
  xrow <- sample(1:16,1) #随机挑选出一个
  Rclusterx2 <- as.character(Rclusterx[xrow,])
  for(i in 1:245){
    for(j in 1:8){
      if(x$code[i] == Rclusterx2[j]){
        x$adjclu[i] <-  x$V1[i]+1
      }
    }
  }
  x$var <- x$adjclu-x$V1
  sim <- merge(x,pop)
  colnames(sim) <- c("code","x1","x","var","name","year","pop")
  xsim[,q] <- x$adjclu 
  ncases <- 3000;RR <- 3;nsim <- 1;beta <- 1.5;theta <- 1.1 
  simcase <- GenerateSimData(basedat = sim,totalcases = ncases,cluster = Rcluster2,
                               beta = beta,RR = RR,theta=theta, nsim=nsim) #每一列的总例数是3000[病例]，一个随机
  simcase1[,q] <- simcase
}
setwd("D:/covariance/simuldata/0706")
write.csv(simcase1,"sim.csv") #实际发病数
write.csv(xsim,"xsim.csv") #存储配套的X文件


####(1)2x3y#########
xcenter1 <- read.table(pathdat%+%"xcenter.csv",
                       stringsAsFactors = F,header = F,colClasses = c("character"))
xcenter <- as.character(xcenter1$V2)
size=8
Rclusterx=c()
for (i in 1:16){
  xcenter1 <- xcenter[i]
  Rcluster1 <- GenerateClustercode(centre = xcenter1 ,shape = 1,num_county = size,geodat = geo)
  Rclusterx <- rbind(Rclusterx,Rcluster1)
}
Rclusterx <- data.frame(Rclusterx)
#模拟
{
  simutime = 2000
  xsim <- matrix(ncol = simutime,nrow = 245)
  row.names(xsim) <- pop$code
  simcase1 <- matrix(ncol = simutime,nrow = 245)
  row.names(simcase1) <- pop$code
}
for(q in 1:simutime){
  s <- nrow(geo)
  resx <- rnorm(s,0,1) #生成随机误差，一个随机
  I <- diag(rep(1,s)) #生成单位矩阵
  xro <- 0.7 #空间自相关系数
  x <- solve(I-xro*w) %*% resx #生成X
  x <- as.data.frame(x)
  x$code <- geo$code
  x$adjclu <- x$V1
  #两个高聚集区
  xrow <- sample(1:16,1) #随机挑选出一个
  Rclusterx2.1 <- as.character(Rclusterx[xrow,])
  for(i in 1:245){
    for(j in 1:8){
      if(x$code[i] == Rclusterx2.1[j]){
        x$adjclu[i] <-  x$V1[i]+1
      }
    }
  }
  x$var <- x$adjclu-x$V1
  Rclusterx.1 <- Rclusterx[-xrow,]
  xrow2 <- sample(1:15,1)
  Rclusterx2.2 <- as.character(Rclusterx.1[xrow2,])
  #聚集区的X加Cx
  for(i in 1:245){
    for(j in 1:8){
      if(x$code[i] == Rclusterx2.2[j]){
        x$adjclu[i] <-  x$V1[i]-1
      }
    }
  }
  x$var <- x$adjclu-x$V1
  sim <- merge(x,pop)
  colnames(sim) <- c("code","x1","x","var","name","year","pop")
  xsim[,q] <- x$adjclu
  ncases <- 3000;RR <- 3;nsim <- 1;beta <- 1.5;theta <- 1.1 
  simcase <- GenerateSimData(basedat = sim,totalcases = ncases,cluster = Rcluster2,
                               beta = beta,RR = RR,theta=theta, nsim=nsim) #每一列的总例数是3000[病例]，一个随机
  simcase1[,q] <- simcase
}
setwd("D:/covariance/simuldata/0706")
write.csv(simcase1,"sim.csv") #实际发病数
write.csv(xsim,"xsim.csv") #存储配套的X文件





